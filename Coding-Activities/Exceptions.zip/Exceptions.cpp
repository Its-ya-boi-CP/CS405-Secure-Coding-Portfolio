// Exceptions.cpp: Demonstrates standard, custom, and catch-all handlers.
#include <iostream>
#include <exception>
#include <stdexcept>

// Derive from std::exception so callers can use the standard exception interface.
class CustomException : public std::exception
{
public:
    // Return a fixed message without throwing or returning a temporary string.
    const char* what() const noexcept override
    {
        return "A custom application exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Deliberately throw a standard exception to demonstrate error handling.
    throw std::runtime_error(
        "Even More Custom Application Logic encountered an error."
    );

    // Retain the original success path; the demonstration throw skips this line.
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Handle the nested call locally so processing continues after its error.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded."
                      << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        // Catch by const reference and display the exception's own explanation.
        std::cout << "Standard exception caught: " << ex.what() << std::endl;
    }

    // Pass this application-specific error to the explicit handler in main().
    throw CustomException();

    // The throw transfers control to main(), so this original line is skipped.
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Floating-point division does not automatically throw a C++ exception.
    // Reject zero explicitly before attempting the division.
    if (den == 0.0f)
    {
        throw std::invalid_argument("Cannot divide by zero.");
    }
    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    // Catch only divide's intended exception type, as required by the assignment.
    // noexcept is retained: any OTHER escaping exception would call terminate.
    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator
                  << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex)
    {
        std::cout << "Division exception caught: " << ex.what() << std::endl;
    }
}

int main()
{
    // Include startup output and both calls in the application-level try block.
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    // The derived type must come first or std::exception would catch it instead.
    catch (const CustomException& ex)
    {
        std::cout << "Custom exception caught: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "Standard exception caught in main: " << ex.what()
                  << std::endl;
    }
    catch (...)
    {
        // Last resort for an unmatched C++ exception reaching this try block.
        // No exception object is available here, so there is no what() to call.
        std::cout << "An unknown exception was caught." << std::endl;
    }

    // The deliberately triggered demonstration errors have been handled.
    return 0;
}
