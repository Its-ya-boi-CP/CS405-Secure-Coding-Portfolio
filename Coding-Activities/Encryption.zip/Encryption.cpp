// Encryption.cpp : This file contains the 'main' function.
// Program execution begins and ends there.

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <stdexcept>
#include <filesystem>

/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// </summary>
/// <param name="source">Input string to process.</param>
/// <param name="key">Key to use in encryption/decryption.</param>
/// <returns>Transformed string.</returns>
std::string encrypt_decrypt(
    const std::string& source,
    const std::string& key)
{
    // Store the lengths once so they do not need to be calculated
    // during every iteration of the loop.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Verify that both the key and source contain data.
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Process the source string one character at a time.
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character with a character from the key.
        // The modulus operator repeats the key when the
        // source string is longer than the password.
        output[i] = source[i] ^ key[i % key_length];
    }

    // Encryption should change the contents but not the length.
    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the requested input file.
    std::ifstream input_file(filename);

    // Stop processing if the file could not be opened.
    if (!input_file.is_open())
    {
        throw std::runtime_error(
            "Unable to open input file: " + filename
        );
    }

    // Read the entire file, including line breaks,
    // into a string stream.
    std::stringstream buffer;
    buffer << input_file.rdbuf();

    // Convert the stream into one string.
    std::string file_text = buffer.str();

    input_file.close();

    return file_text;
}

std::string get_student_name(
    const std::string& string_data)
{
    std::string student_name;

    // Find the first newline in the input file.
    size_t pos = string_data.find('\n');

    // If a newline was found, everything before it
    // is the student's name.
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(
    const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    // Open the output file in binary mode so encrypted
    // characters are written exactly as they exist.
    std::ofstream output_file(
        filename,
        std::ios::binary
    );

    // Verify that the output file opened correctly.
    if (!output_file.is_open())
    {
        throw std::runtime_error(
            "Unable to create output file: " + filename
        );
    }

    // Get the current system date.
    std::time_t current_time = std::time(nullptr);
    std::tm time_info{};

    // Safe Microsoft/Visual Studio version of localtime.
    localtime_s(
        &time_info,
        &current_time
    );

    // Format the date as yyyy-mm-dd.
    std::ostringstream date_stream;
    date_stream << std::put_time(
        &time_info,
        "%Y-%m-%d"
    );

    // Required file format:
    // Line 1: student name
    // Line 2: date
    // Line 3: key
    // Line 4+: encrypted/decrypted data
    output_file << student_name << '\n';
    output_file << date_stream.str() << '\n';
    output_file << key << '\n';

    // write() is used because encrypted data may contain
    // characters that cannot be displayed normally as text.
    output_file.write(
        data.data(),
        static_cast<std::streamsize>(data.size())
    );

    output_file.close();
}

int main()
{
    std::cout
        << "Encryption Decryption Test!"
        << std::endl;

    // Display the folder where Visual Studio is currently
    // looking for inputdatafile.txt and saving output files.
    std::cout
        << "Working directory: "
        << std::filesystem::current_path()
        << std::endl;

    try
    {
        // Input file format:
        // Line 1: Student name
        // Line 2: Lorem Ipsum generator website
        // Lines 3+: Three paragraphs of generated text

        const std::string file_name =
            "inputdatafile.txt";

        const std::string encrypted_file_name =
            "encrypteddatafile.txt";

        // Keep this spelling because it is the filename
        // provided in the original starter code.
        const std::string decrypted_file_name =
            "decrytpteddatafile.txt";

        const std::string key =
            "password";

        // Load the original input file into a string.
        const std::string source_string =
            read_file(file_name);

        // Get the student name from line 1 of the file.
        const std::string student_name =
            get_student_name(source_string);

        // Encrypt the original data using XOR.
        const std::string encrypted_string =
            encrypt_decrypt(
                source_string,
                key
            );

        // Save the encrypted data.
        save_data_file(
            encrypted_file_name,
            student_name,
            key,
            encrypted_string
        );

        // Apply XOR again with the same key to decrypt.
        const std::string decrypted_string =
            encrypt_decrypt(
                encrypted_string,
                key
            );

        // Verify that the decrypted data matches
        // the original input exactly.
        if (source_string == decrypted_string)
        {
            std::cout
                << "Decryption successful! "
                << "Original data was restored."
                << std::endl;
        }
        else
        {
            std::cout
                << "Decryption failed. "
                << "Original data was not restored."
                << std::endl;
        }

        // Save the decrypted data.
        save_data_file(
            decrypted_file_name,
            student_name,
            key,
            decrypted_string
        );

        std::cout
            << "Read File: "
            << file_name
            << " - Encrypted To: "
            << encrypted_file_name
            << " - Decrypted To: "
            << decrypted_file_name
            << std::endl;
    }
    catch (const std::exception& ex)
    {
        // Display a useful error instead of allowing
        // the program to terminate without explanation.
        std::cout
            << "Error: "
            << ex.what()
            << std::endl;
    }

    return 0;
}
