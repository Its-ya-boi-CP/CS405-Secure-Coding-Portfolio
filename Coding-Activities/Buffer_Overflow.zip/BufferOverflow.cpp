// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>   // Added to use std::string for safe, dynamically sized input storage.

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  // The original char array had 20 slots. A C-style string needs one slot for the null terminator,
  // so 19 visible characters is the largest input that would safely fit in that original buffer.
  const std::size_t MAX_INPUT_LENGTH = 19;

  const std::string account_number = "CharlieBrown42";
  std::string user_input;  // Changed from char[20] so long input cannot write past a fixed-size buffer.

  std::cout << "Enter a value: ";
  std::cin >> user_input;  // std::string grows as needed instead of overflowing adjacent memory.

  // Reject input that would have been too large for the original 20-character C-style buffer.
  if (user_input.length() > MAX_INPUT_LENGTH)
  {
    std::cout << "Input is too long. Maximum allowed length is "
              << MAX_INPUT_LENGTH << " characters." << std::endl;
  }
  else
  {
    std::cout << "You entered: " << user_input << std::endl;
  }

  // The account number is displayed after validation to show that excessive input cannot modify it.
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
